#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PALIMPSEST v0.3
A multilingual literary montage / prose-poem composition environment.

Core ideas:
- The archive is primary; originals are never modified.
- Blank-line blocks preserve poems, stanzas, fragments, and prose units.
- Recombination is reproducible and provenance-rich.
- Continuity is plural: lexical/morphological resonance, motif, period,
  local source flow, language, genre/register, and deliberate rupture.
- Human curation can KEEP / REJECT / FREEZE fragments and feed decisions
  back into later compositions.
- Dates are optional metadata. Unknown dates remain unknown.

No third-party Python packages are required.
Python 3.9+.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
import sys
import time
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

VERSION = "0.3"
SUPPORTED_EXTENSIONS = {".txt", ".md", ".markdown", ".text"}
WORD_RE = re.compile(r"[^\W\d_]+(?:['’\-][^\W\d_]+)*", re.UNICODE)
YEAR_RE = re.compile(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)")
DATE_LINE_RES = [
    re.compile(r"^\s*(\d{1,2})[.\-/](\d{1,2})[.\-/](19\d{2}|20\d{2})\s*$"),
    re.compile(r"^\s*(19\d{2}|20\d{2})[.\-/](\d{1,2})[.\-/](\d{1,2})\s*$"),
    re.compile(r"^\s*(19\d{2}|20\d{2})\s*$"),
]

FI_STOP = {
    "ja", "on", "oli", "ovat", "että", "se", "ei", "kun", "mutta", "niin", "kuin",
    "minä", "sinä", "hän", "me", "te", "he", "tämä", "tuo", "joka", "mitä", "mikä",
    "myös", "vielä", "vain", "tai", "jos", "sen", "sitä", "tässä", "siinä", "jotain",
    "jokin", "olla", "olen", "ole", "oli", "olisi", "ovat", "sitten", "nyt", "jo", "en",
    "et", "emme", "ette", "eivät", "minun", "sinun", "hänen", "meidän", "heidän", "ne",
    "tämän", "siitä", "jossa", "jonka", "jolloin", "kanssa", "ilman", "yli", "alle"
}
EN_STOP = {
    "the", "and", "is", "was", "were", "are", "that", "it", "not", "when", "but", "as",
    "i", "you", "he", "she", "we", "they", "this", "which", "what", "also", "still",
    "only", "or", "if", "of", "to", "in", "with", "from", "for", "a", "an", "be", "been",
    "being", "at", "by", "on", "into", "out", "there", "here", "then", "than", "my", "your",
    "his", "her", "our", "their", "its", "do", "did", "does", "have", "had", "has"
}
ALL_STOP = FI_STOP | EN_STOP

FI_SUFFIXES = (
    "kin", "kaan", "kään", "ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle",
    "ksi", "tta", "ttä", "ine", "mme", "nne", "nsa", "nsä", "seen", "siin", "taan", "tään",
    "na", "nä", "tta", "ttä", "den", "jen", "ien", "en", "n", "t"
)
EN_SUFFIXES = ("ingly", "edly", "ing", "ed", "ly", "ness", "ment", "ments", "es", "s")


@dataclass(frozen=True)
class Fragment:
    uid: str
    source_group: str
    source_file: str
    source_index: int
    text: str
    language_hint: str
    words: Tuple[str, ...]
    terms: Tuple[str, ...]
    chargrams: Tuple[str, ...]
    year: Optional[int]
    period: str
    genre: str
    tags: Tuple[str, ...]


@dataclass
class Chosen:
    output_index: int
    fragment: Fragment
    reason: str
    score: float = 0.0


@dataclass
class Curation:
    keep: Set[str] = field(default_factory=set)
    reject: Set[str] = field(default_factory=set)
    freeze: Set[str] = field(default_factory=set)


# ---------------------------- text / metadata ----------------------------

def read_text_file(path: Path) -> str:
    data = path.read_bytes()
    last = None
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError as exc:
            last = exc
    assert last is not None
    raise last


def split_units(text: str, mode: str) -> List[str]:
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip("\n")
    if not text.strip():
        return []
    if mode == "document":
        return [text]
    if mode == "line":
        return [ln for ln in text.split("\n") if ln.strip()]
    if mode == "sentence":
        # Conservative prose-oriented splitter. For poetry, use block.
        chunks = re.split(r"(?<=[.!?…])\s+(?=[A-ZÅÄÖa-zåäö0-9\"'“‘(])", text)
        return [c.strip() for c in chunks if c.strip()]
    parts = re.split(r"\n[ \t]*\n+", text)
    return [p.strip("\n") for p in parts if p.strip()]


def normalize_word(word: str) -> str:
    return unicodedata.normalize("NFC", word).casefold().strip("-'’")


def tokenize(text: str) -> Tuple[str, ...]:
    return tuple(normalize_word(w) for w in WORD_RE.findall(text) if normalize_word(w))


def language_hint(words: Sequence[str]) -> str:
    if not words:
        return "unknown"
    sample = words[:400]
    fi = sum(1 for w in sample if w in FI_STOP)
    en = sum(1 for w in sample if w in EN_STOP)
    finnish_letters = sum(1 for w in sample if any(c in w for c in "äö"))
    fi += min(4, finnish_letters)
    if fi >= en + 2:
        return "fi"
    if en >= fi + 2:
        return "en"
    return "mixed/unknown"


def light_stem(word: str, lang: str) -> str:
    if len(word) < 5:
        return word
    suffixes = FI_SUFFIXES if lang == "fi" else EN_SUFFIXES if lang == "en" else ()
    for suf in suffixes:
        if word.endswith(suf) and len(word) - len(suf) >= 4:
            return word[:-len(suf)]
    return word


def analysis_terms(words: Sequence[str], lang: str) -> Tuple[str, ...]:
    out = []
    for w in words:
        if w in ALL_STOP or len(w) < 2:
            continue
        s = light_stem(w, lang)
        if s and s not in ALL_STOP:
            out.append(s)
    return tuple(out)


def make_chargrams(terms: Sequence[str]) -> Tuple[str, ...]:
    grams: Set[str] = set()
    for term in set(terms):
        if len(term) < 5:
            continue
        padded = f"^{term}$"
        for n in (4, 5):
            if len(padded) >= n:
                for i in range(len(padded) - n + 1):
                    grams.add(padded[i:i+n])
    # Cap pathological blocks while retaining deterministic selection.
    return tuple(sorted(grams)[:1200])


def infer_year(relpath: str, text: str) -> Optional[int]:
    # File/path year is useful and relatively intentional.
    years = YEAR_RE.findall(relpath)
    if years:
        return int(years[-1])
    # Only accept a date-like line near the very beginning, not arbitrary cited years.
    for line in text.splitlines()[:8]:
        for rx in DATE_LINE_RES:
            m = rx.match(line)
            if m:
                for g in m.groups():
                    if g and len(g) == 4 and (g.startswith("19") or g.startswith("20")):
                        return int(g)
    return None


def default_period(year: Optional[int]) -> str:
    return f"{year // 10 * 10}s" if year else "undated"


def guess_genre(block: str) -> str:
    lines = [ln for ln in block.splitlines() if ln.strip()]
    if not lines:
        return "fragment"
    avg = sum(len(ln) for ln in lines) / len(lines)
    wc = len(WORD_RE.findall(block))
    if len(lines) >= 2 and avg <= 55:
        return "poem"
    if wc >= 100 or avg >= 90:
        return "prose"
    return "fragment"


def metadata_path(folder: Path) -> Path:
    return folder / "PALIMPSEST_METADATA.json"


def load_metadata(folder: Path) -> dict:
    path = metadata_path(folder)
    if not path.exists():
        return {"defaults": {}, "files": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"Cannot read metadata file {path}: {exc}")
    if not isinstance(data, dict):
        raise ValueError(f"Metadata root must be an object: {path}")
    data.setdefault("defaults", {})
    data.setdefault("files", {})
    return data


def file_meta(meta: dict, rel: str) -> dict:
    out = dict(meta.get("defaults", {}))
    specific = meta.get("files", {}).get(rel, {})
    if isinstance(specific, dict):
        out.update(specific)
    return out


def fragment_uid(group: str, rel: str, index: int, text: str) -> str:
    payload = f"{group}\0{rel}\0{index}\0{text}".encode("utf-8", errors="replace")
    return hashlib.sha256(payload).hexdigest()[:20]


def load_group(folder: Path, group: str, unit: str) -> Tuple[List[Fragment], List[dict]]:
    if not folder.exists() or not folder.is_dir():
        raise FileNotFoundError(f"Source folder does not exist: {folder}")
    meta = load_metadata(folder)
    fragments: List[Fragment] = []
    inventory: List[dict] = []

    files = sorted(
        p for p in folder.rglob("*")
        if p.is_file()
        and p.suffix.lower() in SUPPORTED_EXTENSIONS
        and p.name != "PALIMPSEST_METADATA.json"
    )
    for path in files:
        rel = path.relative_to(folder).as_posix()
        try:
            text = read_text_file(path)
        except Exception as exc:
            print(f"[warning] skipping {path}: {exc}", file=sys.stderr)
            continue
        fm = file_meta(meta, rel)
        inferred = infer_year(rel, text)
        year = fm.get("year", inferred)
        try:
            year = int(year) if year not in (None, "") else None
        except (TypeError, ValueError):
            year = inferred
        period = str(fm.get("period") or default_period(year))
        explicit_genre = fm.get("genre")
        tags = tuple(str(x).casefold() for x in fm.get("tags", []) if str(x).strip())
        units = split_units(text, unit)
        lang_counts = Counter()
        genre_counts = Counter()
        for idx, block in enumerate(units):
            words = tokenize(block)
            lang = language_hint(words)
            terms = analysis_terms(words, lang)
            genre = str(explicit_genre or guess_genre(block))
            lang_counts[lang] += 1
            genre_counts[genre] += 1
            fragments.append(Fragment(
                uid=fragment_uid(group, rel, idx, block),
                source_group=group,
                source_file=rel,
                source_index=idx,
                text=block,
                language_hint=lang,
                words=words,
                terms=terms,
                chargrams=make_chargrams(terms),
                year=year,
                period=period,
                genre=genre,
                tags=tags,
            ))
        inventory.append({
            "group": group,
            "file": rel,
            "year": year,
            "period": period,
            "genre": explicit_genre or "auto",
            "tags": list(tags),
            "units": len(units),
            "languages": dict(lang_counts),
            "guessed_genres": dict(genre_counts),
            "characters": len(text),
        })
    return fragments, inventory


# ---------------------------- filtering / curation ----------------------------

def parse_set(value: str) -> Set[str]:
    return {x.strip().casefold() for x in value.split(",") if x.strip()}


def filter_fragments(
    frags: Sequence[Fragment],
    periods: Set[str],
    year_min: Optional[int],
    year_max: Optional[int],
    languages: Set[str],
    genres: Set[str],
    rejected: Set[str],
) -> List[Fragment]:
    out = []
    for f in frags:
        if f.uid in rejected:
            continue
        if periods and f.period.casefold() not in periods:
            continue
        if year_min is not None and (f.year is None or f.year < year_min):
            continue
        if year_max is not None and (f.year is None or f.year > year_max):
            continue
        if languages and f.language_hint.casefold() not in languages:
            continue
        if genres and f.genre.casefold() not in genres:
            continue
        out.append(f)
    return out


def load_curation(path: Optional[Path]) -> Curation:
    if not path:
        return Curation()
    data = json.loads(path.read_text(encoding="utf-8"))
    decisions = data.get("decisions", data)
    cur = Curation()
    if isinstance(decisions, dict):
        for uid, decision in decisions.items():
            d = str(decision).casefold()
            if d == "reject":
                cur.reject.add(uid)
            elif d == "freeze":
                cur.freeze.add(uid)
                cur.keep.add(uid)
            elif d in ("keep", "favorite", "favourite"):
                cur.keep.add(uid)
    return cur


# ---------------------------- similarity ----------------------------

def jaccard(a: Sequence[str], b: Sequence[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def resonance(a: Fragment, b: Fragment) -> float:
    lexical = jaccard(a.terms, b.terms)
    morph = jaccard(a.chargrams, b.chargrams)
    tag = jaccard(a.tags, b.tags)
    return min(1.0, 0.58 * lexical + 0.30 * morph + 0.12 * tag)


def query_features(query: str) -> Tuple[Set[str], Set[str]]:
    words = tokenize(query)
    lang = language_hint(words)
    terms = set(analysis_terms(words, lang))
    grams = set(make_chargrams(tuple(terms)))
    return terms, grams


def query_score(f: Fragment, qterms: Set[str], qgrams: Set[str]) -> float:
    term = jaccard(f.terms, qterms)
    gram = jaccard(f.chargrams, qgrams)
    exact = 0.0
    fw = set(f.words)
    if qterms:
        exact = len(fw & qterms) / max(1, len(qterms))
    return min(1.0, 0.50 * term + 0.30 * gram + 0.20 * exact)


def motif_score(f: Fragment, motifs: Set[str]) -> float:
    if not motifs:
        return 0.0
    qterms, qgrams = query_features(" ".join(sorted(motifs)))
    return query_score(f, qterms, qgrams)


def period_score(current: Fragment, cand: Fragment, mode: str) -> float:
    if mode == "free":
        return 0.0
    if mode == "same":
        if current.period == "undated" or cand.period == "undated":
            return 0.0
        return 1.0 if current.period == cand.period else -0.25
    if mode == "cross":
        if current.period == "undated" or cand.period == "undated":
            return 0.05
        return 0.8 if current.period != cand.period else -0.15
    if mode == "chronological":
        if current.year is None or cand.year is None:
            return 0.0
        if cand.year >= current.year:
            return 0.7 / (1.0 + abs(cand.year - current.year) / 10.0)
        return -0.35
    return 0.0


def language_score(current: Fragment, cand: Fragment, mode: str, primary: str, intrusion_rate: float) -> float:
    if mode == "free":
        return 0.0
    if mode == "same":
        return 0.5 if cand.language_hint == current.language_hint else -0.15
    if mode == "primary-intrusions":
        if cand.language_hint == primary:
            return 0.45 * (1.0 - intrusion_rate)
        return 0.45 * intrusion_rate
    return 0.0


def weighted_choice(rng: random.Random, items: Sequence[Fragment], weights: Sequence[float]) -> Fragment:
    if not items:
        raise ValueError("No items")
    safe = [max(0.000001, float(w)) for w in weights]
    total = sum(safe)
    x = rng.random() * total
    s = 0.0
    for item, w in zip(items, safe):
        s += w
        if x <= s:
            return item
    return items[-1]


def candidate_weight(
    current: Fragment,
    cand: Fragment,
    motifs: Set[str],
    continuity: float,
    motif_gravity: float,
    period_mode: str,
    period_gravity: float,
    language_mode: str,
    primary_language: str,
    intrusion_rate: float,
    register_shift: float,
    recent_files: Sequence[str],
    favorite_boost: float,
    curation: Curation,
) -> float:
    sim = resonance(current, cand)
    motif = motif_score(cand, motifs)
    pscore = period_score(current, cand, period_mode)
    lscore = language_score(current, cand, language_mode, primary_language, intrusion_rate)
    register = 1.0 if cand.genre != current.genre else 0.0
    source_shift = 0.25 if cand.source_group != current.source_group else 0.0
    cooldown = -0.35 if cand.source_file in recent_files else 0.0

    score = (
        0.10
        + continuity * (2.2 * sim)
        + motif_gravity * (1.8 * motif)
        + period_gravity * pscore
        + lscore
        + register_shift * (0.35 * register + source_shift)
        + cooldown
    )
    if cand.uid in curation.keep:
        score += max(0.0, favorite_boost - 1.0)
    if cand.uid in curation.freeze:
        score += 0.35
    return max(0.001, score)


# ---------------------------- composition engines ----------------------------

def limit_or_all(seq: List[Fragment], count: int) -> List[Fragment]:
    return seq if count <= 0 else seq[:count]


def generate_deck(rng: random.Random, a: Sequence[Fragment], b: Sequence[Fragment], count: int) -> List[Chosen]:
    deck = list(a) + list(b)
    rng.shuffle(deck)
    deck = limit_or_all(deck, count)
    return [Chosen(i, f, "deck") for i, f in enumerate(deck)]


def generate_interleave(rng: random.Random, a: Sequence[Fragment], b: Sequence[Fragment], count: int, ratio_a: float) -> List[Chosen]:
    aa, bb = list(a), list(b)
    rng.shuffle(aa); rng.shuffle(bb)
    ia = ib = 0
    out: List[Chosen] = []
    while len(out) < count and (ia < len(aa) or ib < len(bb)):
        choose_a = rng.random() < ratio_a
        if choose_a and ia < len(aa):
            out.append(Chosen(len(out), aa[ia], "interleave:A")); ia += 1
        elif ib < len(bb):
            out.append(Chosen(len(out), bb[ib], "interleave:B")); ib += 1
        elif ia < len(aa):
            out.append(Chosen(len(out), aa[ia], "interleave:A-fallback")); ia += 1
    return out


def generate_braid(rng: random.Random, a: Sequence[Fragment], b: Sequence[Fragment], count: int, ratio_a: float, run_min: int, run_max: int) -> List[Chosen]:
    aa, bb = list(a), list(b)
    rng.shuffle(aa); rng.shuffle(bb)
    ia = ib = 0
    out: List[Chosen] = []
    while len(out) < count and (ia < len(aa) or ib < len(bb)):
        use_a = rng.random() < ratio_a
        run = rng.randint(run_min, run_max)
        for _ in range(run):
            if len(out) >= count:
                break
            if use_a and ia < len(aa):
                out.append(Chosen(len(out), aa[ia], "braid:A-run")); ia += 1
            elif not use_a and ib < len(bb):
                out.append(Chosen(len(out), bb[ib], "braid:B-run")); ib += 1
            elif ia < len(aa):
                out.append(Chosen(len(out), aa[ia], "braid:A-fallback")); ia += 1
            elif ib < len(bb):
                out.append(Chosen(len(out), bb[ib], "braid:B-fallback")); ib += 1
    return out


def generate_ghost(rng: random.Random, a: Sequence[Fragment], b: Sequence[Fragment], count: int, ghost_rate: float) -> List[Chosen]:
    aa, bb = list(a), list(b)
    if not aa:
        return []
    start = rng.randrange(len(aa))
    aa = aa[start:] + aa[:start]
    bi = list(range(len(bb))); rng.shuffle(bi)
    ia = ib = 0
    out: List[Chosen] = []
    while len(out) < count and ia < len(aa):
        out.append(Chosen(len(out), aa[ia], "ghost:primary")); ia += 1
        if len(out) >= count:
            break
        if bb and rng.random() < ghost_rate:
            f = bb[bi[ib % len(bi)]]; ib += 1
            out.append(Chosen(len(out), f, "ghost:intrusion"))
    return out[:count]


def local_neighbors(current: Fragment, pool: Sequence[Fragment], used: Set[str], radius: int = 1) -> List[Fragment]:
    return [
        f for f in pool
        if f.uid not in used
        and f.source_group == current.source_group
        and f.source_file == current.source_file
        and 0 < abs(f.source_index - current.source_index) <= radius
    ]


def choose_affinity_next(
    rng: random.Random,
    current: Fragment,
    candidates: Sequence[Fragment],
    motifs: Set[str],
    args: argparse.Namespace,
    recent_files: Sequence[str],
    curation: Curation,
) -> Tuple[Fragment, float]:
    if not candidates:
        raise ValueError("No candidates")
    k = min(len(candidates), max(1, args.candidate_sample))
    sample = rng.sample(list(candidates), k=k)
    weights = [
        candidate_weight(
            current, f, motifs, args.continuity, args.motif_gravity,
            args.period_mode, args.period_gravity, args.language_mode,
            args.primary_language, args.intrusion_rate, args.register_shift,
            recent_files, args.favorite_boost, curation
        ) for f in sample
    ]
    pick = weighted_choice(rng, sample, weights)
    return pick, weights[sample.index(pick)]


def choose_start(rng: random.Random, pool: Sequence[Fragment], motifs: Set[str], curation: Curation) -> Fragment:
    fav = [f for f in pool if f.uid in curation.freeze]
    if fav:
        return rng.choice(fav)
    hits = [f for f in pool if motif_score(f, motifs) > 0.04]
    if hits:
        return rng.choice(hits)
    kept = [f for f in pool if f.uid in curation.keep]
    if kept:
        return rng.choice(kept)
    return rng.choice(list(pool))


def generate_echo_or_canto(
    rng: random.Random,
    a: Sequence[Fragment],
    b: Sequence[Fragment],
    count: int,
    motifs: Set[str],
    args: argparse.Namespace,
    curation: Curation,
    canto: bool,
) -> List[Chosen]:
    pool = list(a) + list(b)
    if not pool:
        return []
    current = choose_start(rng, pool, motifs, curation)
    out = [Chosen(0, current, "canto:start" if canto else "echo:start", 1.0)]
    used = {current.uid}
    recent_files = [current.source_file]

    while len(out) < count and len(used) < len(pool):
        unused = [f for f in pool if f.uid not in used]
        if not unused:
            break

        # CANTO preserves occasional local runs from the original document.
        if canto and rng.random() < args.preserve_run:
            neigh = local_neighbors(current, pool, used, radius=max(1, args.local_radius))
            if neigh:
                # Prefer the next forward block when present.
                forward = [f for f in neigh if f.source_index > current.source_index]
                nxt = min(forward, key=lambda f: f.source_index) if forward else rng.choice(neigh)
                out.append(Chosen(len(out), nxt, "canto:local-run", 1.0))
                used.add(nxt.uid); current = nxt
                recent_files = (recent_files + [nxt.source_file])[-args.source_cooldown:]
                continue

        # Deliberate rupture: distant material without continuity scoring.
        if canto and rng.random() < args.rupture:
            distant = [f for f in unused if f.source_file not in recent_files]
            if not distant:
                distant = unused
            nxt = rng.choice(distant)
            out.append(Chosen(len(out), nxt, "canto:rupture", 0.0))
            used.add(nxt.uid); current = nxt
            recent_files = (recent_files + [nxt.source_file])[-args.source_cooldown:]
            continue

        # Respect source balance softly.
        desired_group = "A" if rng.random() < args.ratio_a else "B"
        candidates = [f for f in unused if f.source_group == desired_group]
        if not candidates:
            candidates = unused

        nxt, score = choose_affinity_next(
            rng, current, candidates, motifs, args, recent_files, curation
        )
        reason = "canto:affinity" if canto else "echo:affinity"
        out.append(Chosen(len(out), nxt, reason, score))
        used.add(nxt.uid); current = nxt
        recent_files = (recent_files + [nxt.source_file])[-args.source_cooldown:]
    return out


def generate_constellation(
    rng: random.Random,
    a: Sequence[Fragment],
    b: Sequence[Fragment],
    count: int,
    motifs: Set[str],
    args: argparse.Namespace,
    curation: Curation,
) -> List[Chosen]:
    pool = list(a) + list(b)
    if not pool:
        return []
    current = choose_start(rng, pool, motifs, curation)
    out = [Chosen(0, current, "constellation:start", motif_score(current, motifs))]
    used = {current.uid}
    recent_files = [current.source_file]
    # If no explicit motif was supplied, derive weak attractors from the start fragment.
    effective_motifs = set(motifs) or set(current.terms[:10])

    while len(out) < count and len(used) < len(pool):
        unused = [f for f in pool if f.uid not in used]
        desired_group = "A" if rng.random() < args.ratio_a else "B"
        candidates = [f for f in unused if f.source_group == desired_group] or unused
        k = min(len(candidates), max(1, args.candidate_sample))
        sample = rng.sample(candidates, k=k)
        weights = []
        for f in sample:
            attract = motif_score(f, effective_motifs)
            echo = resonance(current, f)
            p = period_score(current, f, args.period_mode)
            reg = 0.25 if f.genre != current.genre else 0.0
            cool = -0.25 if f.source_file in recent_files else 0.0
            w = 0.08 + args.motif_gravity * 2.8 * attract + args.continuity * 1.1 * echo + args.period_gravity * p + args.register_shift * reg + cool
            if f.uid in curation.keep:
                w += max(0.0, args.favorite_boost - 1.0)
            weights.append(max(0.001, w))
        nxt = weighted_choice(rng, sample, weights)
        score = weights[sample.index(nxt)]
        out.append(Chosen(len(out), nxt, "constellation:attractor", score))
        used.add(nxt.uid); current = nxt
        recent_files = (recent_files + [nxt.source_file])[-args.source_cooldown:]
        # Very slowly let successful fragment terms enter the constellation.
        if args.constellation_growth > 0 and rng.random() < args.constellation_growth:
            for term in nxt.terms[:3]:
                if len(effective_motifs) < 40:
                    effective_motifs.add(term)
    return out


def apply_returns(rng: random.Random, chosen: List[Chosen], rate: float, distance: int, curation: Curation) -> List[Chosen]:
    if rate <= 0 or len(chosen) <= distance:
        return chosen
    out: List[Chosen] = []
    for item in chosen:
        if len(out) >= distance and rng.random() < rate:
            eligible = out[:-distance + 1] if distance > 1 else out[:]
            if eligible:
                frozen = [x for x in eligible if x.fragment.uid in curation.freeze]
                source = rng.choice(frozen if frozen else eligible)
                out.append(Chosen(len(out), source.fragment, f"return:from={source.output_index}", source.score))
        out.append(Chosen(len(out), item.fragment, item.reason, item.score))
    for i, x in enumerate(out):
        x.output_index = i
    return out


# ---------------------------- output / manifest ----------------------------

def separator_value(name: str) -> str:
    return {"blank": "\n\n", "linebreak": "\n", "marker": "\n\n* * *\n\n"}[name]


def render_text(chosen: Sequence[Chosen], separator: str, canto_break_every: int = 0) -> str:
    parts = []
    for i, item in enumerate(chosen):
        if canto_break_every > 0 and i > 0 and i % canto_break_every == 0:
            parts.append("§")
        parts.append(item.fragment.text)
    return separator.join(parts).rstrip() + "\n"


def manifest_for(args: argparse.Namespace, seed: int, chosen: Sequence[Chosen], stats: dict, motifs: Set[str]) -> dict:
    return {
        "program": "PALIMPSEST",
        "version": VERSION,
        "created_unix": time.time(),
        "seed": seed,
        "settings": {
            "mode": args.mode,
            "unit": args.unit,
            "count": args.count,
            "ratio_a": args.ratio_a,
            "continuity": args.continuity,
            "motifs": sorted(motifs),
            "motif_gravity": args.motif_gravity,
            "period_mode": args.period_mode,
            "period_gravity": args.period_gravity,
            "language_mode": args.language_mode,
            "primary_language": args.primary_language,
            "intrusion_rate": args.intrusion_rate,
            "register_shift": args.register_shift,
            "preserve_run": args.preserve_run,
            "rupture": args.rupture,
            "return_rate": args.return_rate,
            "return_distance": args.return_distance,
            "candidate_sample": args.candidate_sample,
        },
        "sources": {"A": str(args.a), "B": str(args.b), "stats": stats},
        "output": [
            {
                "output_index": x.output_index,
                "uid": x.fragment.uid,
                "reason": x.reason,
                "score": round(float(x.score), 6),
                "source_group": x.fragment.source_group,
                "source_file": x.fragment.source_file,
                "source_index": x.fragment.source_index,
                "year": x.fragment.year,
                "period": x.fragment.period,
                "genre": x.fragment.genre,
                "language_hint": x.fragment.language_hint,
                "tags": list(x.fragment.tags),
                "text": x.fragment.text,
            }
            for x in chosen
        ],
    }


def write_lineage(path: Path, chosen: Sequence[Chosen]) -> None:
    rows = ["# PALIMPSEST lineage", "# output\tgroup\tfile\tunit\tyear\tperiod\tgenre\tlanguage\treason\tuid"]
    for x in chosen:
        f = x.fragment
        rows.append("\t".join([
            str(x.output_index), f.source_group, f.source_file, str(f.source_index),
            "" if f.year is None else str(f.year), f.period, f.genre, f.language_hint,
            x.reason, f.uid
        ]))
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")


# ---------------------------- commands ----------------------------

def cmd_scan(args: argparse.Namespace) -> int:
    a, inv_a = load_group(args.a, "A", args.unit)
    b, inv_b = load_group(args.b, "B", args.unit)
    inventory = inv_a + inv_b
    args.out.parent.mkdir(parents=True, exist_ok=True)
    json_path = args.out.with_suffix(".json")
    csv_path = args.out.with_suffix(".csv")
    json_path.write_text(json.dumps({
        "program": "PALIMPSEST", "version": VERSION,
        "A_fragments": len(a), "B_fragments": len(b), "files": inventory
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    with csv_path.open("w", encoding="utf-8", newline="") as fh:
        fieldnames = ["group", "file", "year", "period", "genre", "tags", "units", "languages", "guessed_genres", "characters"]
        wr = csv.DictWriter(fh, fieldnames=fieldnames)
        wr.writeheader()
        for row in inventory:
            r = dict(row)
            r["tags"] = ",".join(r["tags"])
            r["languages"] = json.dumps(r["languages"], ensure_ascii=False)
            r["guessed_genres"] = json.dumps(r["guessed_genres"], ensure_ascii=False)
            wr.writerow(r)
    unknown = sum(1 for x in inventory if x["year"] is None)
    print(f"PALIMPSEST v{VERSION} archive scan")
    print(f"files: {len(inventory)} | A units: {len(a)} | B units: {len(b)} | undated files: {unknown}")
    print(f"JSON: {json_path}")
    print(f"CSV:  {csv_path}")
    return 0


def prepare_compose(args: argparse.Namespace) -> Tuple[List[Fragment], List[Fragment], Curation]:
    cur = load_curation(args.curation)
    a, _ = load_group(args.a, "A", args.unit)
    b, _ = load_group(args.b, "B", args.unit)
    a = filter_fragments(a, parse_set(args.period_a), args.year_min, args.year_max, parse_set(args.languages), parse_set(args.genres), cur.reject)
    b = filter_fragments(b, parse_set(args.period_b), args.year_min, args.year_max, parse_set(args.languages), parse_set(args.genres), cur.reject)
    return a, b, cur


def cmd_compose(args: argparse.Namespace) -> int:
    args.ratio_a = max(0.0, min(1.0, args.ratio_a))
    for key in ("continuity", "motif_gravity", "period_gravity", "register_shift", "preserve_run", "rupture", "return_rate", "intrusion_rate", "constellation_growth"):
        setattr(args, key, max(0.0, min(1.0, getattr(args, key))))
    args.run_min = max(1, args.run_min); args.run_max = max(args.run_min, args.run_max)
    args.return_distance = max(1, args.return_distance)
    args.candidate_sample = max(1, args.candidate_sample)
    args.source_cooldown = max(1, args.source_cooldown)
    args.local_radius = max(1, args.local_radius)
    args.favorite_boost = max(1.0, args.favorite_boost)

    seed = args.seed if args.seed is not None else random.SystemRandom().randrange(2**63)
    rng = random.Random(seed)
    a, b, cur = prepare_compose(args)
    if not a and not b:
        print("No usable fragments remain after filtering.", file=sys.stderr)
        return 1
    motifs = parse_set(args.motif)

    if args.mode == "deck":
        chosen = generate_deck(rng, a, b, args.count)
    elif args.mode == "interleave":
        chosen = generate_interleave(rng, a, b, args.count, args.ratio_a)
    elif args.mode == "braid":
        chosen = generate_braid(rng, a, b, args.count, args.ratio_a, args.run_min, args.run_max)
    elif args.mode == "ghost":
        chosen = generate_ghost(rng, a, b, args.count, args.ghost_rate)
    elif args.mode == "echo":
        chosen = generate_echo_or_canto(rng, a, b, args.count, motifs, args, cur, canto=False)
    elif args.mode == "constellation":
        chosen = generate_constellation(rng, a, b, args.count, motifs, args, cur)
    else:
        chosen = generate_echo_or_canto(rng, a, b, args.count, motifs, args, cur, canto=True)

    chosen = apply_returns(rng, chosen, args.return_rate, args.return_distance, cur)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(render_text(chosen, separator_value(args.separator), args.canto_break_every), encoding="utf-8")
    manifest_path = args.out.with_suffix(args.out.suffix + ".manifest.json")
    lineage_path = args.out.with_suffix(args.out.suffix + ".lineage.tsv")
    manifest = manifest_for(args, seed, chosen, {"A_fragments": len(a), "B_fragments": len(b), "output_fragments": len(chosen)}, motifs)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    write_lineage(lineage_path, chosen)

    print(f"PALIMPSEST v{VERSION}")
    print(f"mode: {args.mode} | seed: {seed}")
    print(f"A: {len(a)} units | B: {len(b)} units | output: {len(chosen)} units")
    print(f"text:     {args.out}")
    print(f"manifest: {manifest_path}")
    print(f"lineage:  {lineage_path}")
    print("Re-use the same --seed and settings to reproduce the composition.")
    return 0


def cmd_search(args: argparse.Namespace) -> int:
    cur = load_curation(args.curation)
    a, _ = load_group(args.a, "A", args.unit)
    b, _ = load_group(args.b, "B", args.unit)
    pool = filter_fragments(list(a) + list(b), parse_set(args.period), args.year_min, args.year_max, parse_set(args.languages), parse_set(args.genres), cur.reject)
    qterms, qgrams = query_features(args.query)
    scored = [(query_score(f, qterms, qgrams), f) for f in pool]
    scored.sort(key=lambda x: x[0], reverse=True)
    top = [(s, f) for s, f in scored[:args.top] if s > 0]
    for rank, (score, f) in enumerate(top, 1):
        preview = " / ".join(ln.strip() for ln in f.text.splitlines()[:3])
        if len(preview) > 220:
            preview = preview[:217] + "..."
        print(f"\n[{rank}] score={score:.3f}  {f.source_group}:{f.source_file}#{f.source_index}")
        print(f"    year={f.year or '?'} period={f.period} genre={f.genre} lang={f.language_hint} uid={f.uid}")
        print(f"    {preview}")
    if not top:
        print("No substantial surface/morphological matches found.")
    return 0


def cmd_curate(args: argparse.Namespace) -> int:
    data = json.loads(args.manifest.read_text(encoding="utf-8"))
    entries = data.get("output", [])
    if not entries:
        print("Manifest contains no output entries.", file=sys.stderr)
        return 1
    out_path = args.out or args.manifest.with_suffix(args.manifest.suffix + ".curation.json")
    decisions: Dict[str, str] = {}
    if out_path.exists():
        try:
            old = json.loads(out_path.read_text(encoding="utf-8"))
            decisions.update(old.get("decisions", {}))
        except Exception:
            pass
    print("PALIMPSEST CURATOR — Enter=keep, x=reject, f=freeze, s=skip, q=save+quit")
    for e in entries:
        uid = e["uid"]
        print("\n" + "=" * 72)
        print(f"#{e['output_index']}  {e['source_group']}:{e['source_file']}#{e['source_index']}  {e.get('period')} / {e.get('genre')} / {e.get('language_hint')}")
        print("-" * 72)
        print(e.get("text", ""))
        previous = decisions.get(uid)
        prompt = f"\n[k/x/f/s/q]" + (f" current={previous}" if previous else "") + ": "
        try:
            ans = input(prompt).strip().casefold()
        except EOFError:
            ans = "q"
        if ans == "q":
            break
        if ans in ("", "k"):
            decisions[uid] = "keep"
        elif ans == "x":
            decisions[uid] = "reject"
        elif ans == "f":
            decisions[uid] = "freeze"
        elif ans == "s":
            continue
    payload = {
        "program": "PALIMPSEST",
        "version": VERSION,
        "source_manifest": str(args.manifest),
        "created_unix": time.time(),
        "decisions": decisions,
    }
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    # Also render a clean curated text of keep/freeze entries in current composition order.
    selected = [e["text"] for e in entries if decisions.get(e["uid"]) in ("keep", "freeze")]
    curated_txt = out_path.with_suffix(".txt")
    curated_txt.write_text("\n\n".join(selected).rstrip() + ("\n" if selected else ""), encoding="utf-8")
    print(f"Curation: {out_path}")
    print(f"Selected text: {curated_txt}")
    return 0


def add_source_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--a", type=Path, required=True, help="Source folder A")
    p.add_argument("--b", type=Path, required=True, help="Source folder B")
    p.add_argument("--unit", choices=("block", "line", "sentence", "document"), default="block")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="palimpsest_v03.py", description="PALIMPSEST v0.3 — literary montage / prose-poem engine")
    sub = p.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="Inventory the archive and infer only safe metadata")
    add_source_args(scan)
    scan.add_argument("--out", type=Path, default=Path("OUTPUT/archive_inventory"), help="Output base path (.json/.csv added)")
    scan.set_defaults(func=cmd_scan)

    compose = sub.add_parser("compose", help="Compose a new montage")
    add_source_args(compose)
    compose.add_argument("--mode", choices=("deck", "interleave", "braid", "ghost", "echo", "canto", "constellation"), default="canto")
    compose.add_argument("--count", type=int, default=60)
    compose.add_argument("--ratio-a", type=float, default=0.5)
    compose.add_argument("--run-min", type=int, default=1)
    compose.add_argument("--run-max", type=int, default=3)
    compose.add_argument("--ghost-rate", type=float, default=0.18)
    compose.add_argument("--continuity", type=float, default=0.62, help="Affinity / echo gravity")
    compose.add_argument("--motif", default="", help="Comma-separated attractor words")
    compose.add_argument("--motif-gravity", type=float, default=0.62)
    compose.add_argument("--period-mode", choices=("free", "same", "cross", "chronological"), default="free")
    compose.add_argument("--period-gravity", type=float, default=0.35)
    compose.add_argument("--language-mode", choices=("free", "same", "primary-intrusions"), default="free")
    compose.add_argument("--primary-language", default="fi")
    compose.add_argument("--intrusion-rate", type=float, default=0.15)
    compose.add_argument("--register-shift", type=float, default=0.34, help="Encourage shifts between poem/prose/fragment and source groups")
    compose.add_argument("--preserve-run", type=float, default=0.34, help="Canto: keep neighboring original blocks together sometimes")
    compose.add_argument("--local-radius", type=int, default=1)
    compose.add_argument("--rupture", type=float, default=0.12, help="Canto: deliberate discontinuity")
    compose.add_argument("--candidate-sample", type=int, default=80)
    compose.add_argument("--source-cooldown", type=int, default=3)
    compose.add_argument("--return-rate", type=float, default=0.06)
    compose.add_argument("--return-distance", type=int, default=7)
    compose.add_argument("--constellation-growth", type=float, default=0.10)
    compose.add_argument("--favorite-boost", type=float, default=1.8)
    compose.add_argument("--curation", type=Path, default=None)
    compose.add_argument("--period-a", default="", help="Optional comma-separated period filters for A")
    compose.add_argument("--period-b", default="", help="Optional comma-separated period filters for B")
    compose.add_argument("--year-min", type=int, default=None)
    compose.add_argument("--year-max", type=int, default=None)
    compose.add_argument("--languages", default="", help="Optional language filter, e.g. fi,en")
    compose.add_argument("--genres", default="", help="Optional genre filter, e.g. poem,fragment")
    compose.add_argument("--seed", type=int, default=None)
    compose.add_argument("--separator", choices=("blank", "linebreak", "marker"), default="blank")
    compose.add_argument("--canto-break-every", type=int, default=0, help="Insert § every N units; 0 disables")
    compose.add_argument("--out", type=Path, default=Path("OUTPUT/palimpsest_canto.txt"))
    compose.set_defaults(func=cmd_compose)

    search = sub.add_parser("search", help="Archaeology: find fragments resonating with a word/phrase")
    add_source_args(search)
    search.add_argument("query")
    search.add_argument("--top", type=int, default=12)
    search.add_argument("--period", default="")
    search.add_argument("--year-min", type=int, default=None)
    search.add_argument("--year-max", type=int, default=None)
    search.add_argument("--languages", default="")
    search.add_argument("--genres", default="")
    search.add_argument("--curation", type=Path, default=None)
    search.set_defaults(func=cmd_search)

    curate = sub.add_parser("curate", help="Human KEEP / REJECT / FREEZE pass over a generated manifest")
    curate.add_argument("manifest", type=Path)
    curate.add_argument("--out", type=Path, default=None)
    curate.set_defaults(func=cmd_curate)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
