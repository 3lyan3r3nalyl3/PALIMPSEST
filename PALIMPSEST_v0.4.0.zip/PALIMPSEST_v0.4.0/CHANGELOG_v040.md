# PALIMPSEST v0.4.0

First graphical instrument edition.

- compact dark tabletop-synth GUI
- dual Source A / Source B ingest decks
- mixed folder + individual-file ingest
- TXT / MD / RTF / HTML / DOCX / ODT / EPUB / PDF import layer
- non-destructive canonical UTF-8 caches
- CANTO, CONSTELLATION, GHOST, BRAID, ECHO, DECK front-panel modes
- nine draggable synthesis knobs
- temporal and multilingual routing controls
- live composite preview
- fragment-by-fragment ancestry monitor
- GUI KEEP / FREEZE / REJECT decisions
- reproducible seed control
- Save As / Copy / output-folder controls
- self-test and headless GUI smoke-test modes

The literary engine remains the proven v0.3 core under the v0.4 instrument panel.
