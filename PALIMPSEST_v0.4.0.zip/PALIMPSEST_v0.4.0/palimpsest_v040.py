#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PALIMPSEST v0.4.0 — tabletop text synthesizer GUI

Two source decks feed the Palimpsest v0.3 literary montage engine.
The GUI adds mixed-format ingest, compact synth-like controls, live preview,
reproducible seeds, and non-destructive export.

No source file is modified. Rich document formats are converted into temporary
plain-text cache files before composition.

Standard library only for the GUI and most importers. PDF import uses `pypdf`
when installed, otherwise the external `pdftotext` command when available.
"""
from __future__ import annotations

import argparse
import html
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
import zipfile
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from xml.etree import ElementTree as ET

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

# Keep engine beside this file.
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import palimpsest_engine as engine

VERSION = "0.4.0"

SUPPORTED = {
    ".txt", ".text", ".md", ".markdown", ".asc", ".log",
    ".rtf", ".html", ".htm", ".docx", ".odt", ".epub", ".pdf"
}

DARK = "#090b0c"
PANEL = "#111416"
PANEL2 = "#171b1e"
EDGE = "#30363a"
TEXT = "#ece9df"
MUTED = "#8c969a"
ACCENT = "#e6a84a"
ACCENT2 = "#9dbb75"
DANGER = "#c86d68"
BLUE = "#82a9b8"


def safe_read_bytes(path: Path) -> str:
    data = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            pass
    return data.decode("utf-8", errors="replace")


class _TextExtractor(HTMLParser):
    BLOCKS = {"p", "div", "section", "article", "header", "footer", "blockquote", "li", "h1", "h2", "h3", "h4", "h5", "h6", "br"}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: List[str] = []
        self.skip = 0
    def handle_starttag(self, tag, attrs):
        t = tag.casefold()
        if t in {"script", "style", "svg", "noscript"}:
            self.skip += 1
        if not self.skip and t in self.BLOCKS:
            self.parts.append("\n")
    def handle_endtag(self, tag):
        t = tag.casefold()
        if t in {"script", "style", "svg", "noscript"} and self.skip:
            self.skip -= 1
        if not self.skip and t in self.BLOCKS:
            self.parts.append("\n")
    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)
    def text(self) -> str:
        s = "".join(self.parts)
        s = re.sub(r"[ \t]+", " ", s)
        s = re.sub(r" *\n *", "\n", s)
        s = re.sub(r"\n{3,}", "\n\n", s)
        return s.strip()


def html_to_text(raw: str) -> str:
    parser = _TextExtractor()
    parser.feed(raw)
    return parser.text()


def rtf_to_text(raw: str) -> str:
    # Conservative RTF stripping. It intentionally preserves paragraph breaks
    # more than typography. Complex embedded objects are ignored.
    s = raw.replace("\\par", "\n\n").replace("\\line", "\n").replace("\\tab", "\t")
    # Decode simple hex escapes such as \'e4.
    def hx(m):
        try:
            return bytes([int(m.group(1), 16)]).decode("cp1252")
        except Exception:
            return ""
    s = re.sub(r"\\'([0-9a-fA-F]{2})", hx, s)
    # Unicode escapes: \u1234? where ? is fallback char.
    def uni(m):
        try:
            n = int(m.group(1))
            if n < 0:
                n += 65536
            return chr(n)
        except Exception:
            return ""
    s = re.sub(r"\\u(-?\d+)\??", uni, s)
    s = re.sub(r"\\[a-zA-Z]+-?\d* ?", "", s)
    s = s.replace("{", "").replace("}", "")
    s = s.replace("\\~", " ").replace("\\-", "").replace("\\_", "-")
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def docx_to_text(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml")
    root = ET.fromstring(xml)
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    blocks: List[str] = []
    for p in root.findall(".//w:p", ns):
        parts: List[str] = []
        for node in p.iter():
            tag = node.tag.rsplit("}", 1)[-1]
            if tag == "t" and node.text:
                parts.append(node.text)
            elif tag == "tab":
                parts.append("\t")
            elif tag in {"br", "cr"}:
                parts.append("\n")
        text = "".join(parts).strip()
        if text:
            blocks.append(text)
    return "\n\n".join(blocks)


def odt_to_text(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        xml = z.read("content.xml")
    root = ET.fromstring(xml)
    paras: List[str] = []
    for el in root.iter():
        local = el.tag.rsplit("}", 1)[-1]
        if local in {"p", "h"}:
            text = "".join(el.itertext()).strip()
            if text:
                paras.append(text)
    return "\n\n".join(paras)


def epub_to_text(path: Path) -> str:
    sections: List[str] = []
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if n.lower().endswith((".xhtml", ".html", ".htm"))]
        # Sorted order is deterministic. It is a safe fallback even when an EPUB's
        # OPF spine is unusually arranged.
        for name in sorted(names):
            try:
                raw = z.read(name).decode("utf-8", errors="replace")
                txt = html_to_text(raw)
                if txt:
                    sections.append(txt)
            except Exception:
                continue
    return "\n\n§\n\n".join(sections)


def pdf_to_text(path: Path) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        pages = []
        for page in reader.pages:
            pages.append((page.extract_text() or "").strip())
        text = "\n\n".join(p for p in pages if p)
        if text.strip():
            return text
    except Exception:
        pass

    exe = shutil.which("pdftotext")
    if exe:
        proc = subprocess.run([exe, "-layout", str(path), "-"], capture_output=True, text=True)
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
    raise RuntimeError("PDF text extraction needs pypdf or the pdftotext command")


def extract_text(path: Path) -> str:
    ext = path.suffix.casefold()
    if ext in {".txt", ".text", ".md", ".markdown", ".asc", ".log"}:
        return safe_read_bytes(path)
    if ext == ".rtf":
        return rtf_to_text(safe_read_bytes(path))
    if ext in {".html", ".htm"}:
        return html_to_text(safe_read_bytes(path))
    if ext == ".docx":
        return docx_to_text(path)
    if ext == ".odt":
        return odt_to_text(path)
    if ext == ".epub":
        return epub_to_text(path)
    if ext == ".pdf":
        return pdf_to_text(path)
    raise ValueError(f"Unsupported format: {path.suffix}")


def iter_source_files(roots: Sequence[Path]) -> List[Path]:
    seen = set()
    out: List[Path] = []
    for root in roots:
        root = Path(root)
        if root.is_file():
            candidates = [root]
        elif root.is_dir():
            candidates = [p for p in root.rglob("*") if p.is_file()]
        else:
            continue
        for p in sorted(candidates):
            if p.suffix.casefold() not in SUPPORTED:
                continue
            key = str(p.resolve())
            if key not in seen:
                seen.add(key)
                out.append(p)
    return out


def slug(name: str, maxlen: int = 70) -> str:
    base = unicodedata.normalize("NFKD", name)
    base = "".join(ch for ch in base if ch.isalnum() or ch in "._- ")
    base = re.sub(r"\s+", "_", base).strip("._")
    return (base or "document")[:maxlen]


@dataclass
class ImportResult:
    cache_dir: Path
    files_ok: int
    files_failed: int
    units_hint: int
    mapping: List[dict]


def ingest_side(roots: Sequence[Path], cache_dir: Path) -> ImportResult:
    if cache_dir.exists():
        shutil.rmtree(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    mapping: List[dict] = []
    ok = failed = units_hint = 0
    for i, src in enumerate(iter_source_files(roots), 1):
        rec = {"source": str(src), "format": src.suffix.casefold(), "status": "ok"}
        try:
            text = extract_text(src)
            if not text.strip():
                raise RuntimeError("no extractable text")
            dest = cache_dir / f"{i:05d}__{slug(src.name)}.txt"
            dest.write_text(text.replace("\r\n", "\n").replace("\r", "\n"), encoding="utf-8")
            rec["cache"] = dest.name
            rec["chars"] = len(text)
            units_hint += max(1, len(re.split(r"\n[ \t]*\n+", text.strip())))
            ok += 1
        except Exception as exc:
            failed += 1
            rec["status"] = "failed"
            rec["error"] = str(exc)
        mapping.append(rec)
    (cache_dir / "IMPORT_MAP.json").write_text(json.dumps(mapping, ensure_ascii=False, indent=2), encoding="utf-8")
    return ImportResult(cache_dir, ok, failed, units_hint, mapping)


class Knob(tk.Canvas):
    """Small draggable synthesizer-style rotary control."""
    def __init__(self, master, label: str, variable: tk.DoubleVar, lo=0.0, hi=1.0, width=72, **kw):
        super().__init__(master, width=width, height=86, bg=PANEL, highlightthickness=0, **kw)
        self.label = label
        self.var = variable
        self.lo = float(lo); self.hi = float(hi)
        self._last_y = None
        self.bind("<Button-1>", self._down)
        self.bind("<B1-Motion>", self._drag)
        self.bind("<MouseWheel>", self._wheel)
        self.bind("<Button-4>", lambda e: self._nudge(+0.02))
        self.bind("<Button-5>", lambda e: self._nudge(-0.02))
        self.var.trace_add("write", lambda *_: self.draw())
        self.draw()
    def _down(self, e):
        self._last_y = e.y
    def _drag(self, e):
        if self._last_y is None: return
        dy = self._last_y - e.y
        self._last_y = e.y
        self._nudge(dy * (self.hi - self.lo) / 140.0)
    def _wheel(self, e):
        self._nudge((1 if e.delta > 0 else -1) * (self.hi-self.lo) * 0.025)
    def _nudge(self, delta):
        self.var.set(max(self.lo, min(self.hi, self.var.get() + delta)))
    def draw(self):
        self.delete("all")
        cx, cy, r = 36, 34, 22
        self.create_oval(cx-r, cy-r, cx+r, cy+r, fill="#0d1011", outline=EDGE, width=2)
        v = (self.var.get() - self.lo) / max(1e-9, self.hi - self.lo)
        angle = math.radians(225 - v * 270)
        x = cx + math.cos(angle)*17; y = cy - math.sin(angle)*17
        self.create_line(cx, cy, x, y, fill=ACCENT, width=3, capstyle="round")
        self.create_text(cx, 62, text=f"{self.var.get():.2f}", fill=TEXT, font=("TkFixedFont", 8))
        self.create_text(cx, 77, text=self.label, fill=MUTED, font=("TkFixedFont", 7, "bold"))


class SourceDeck(tk.Frame):
    def __init__(self, master, name: str, accent: str, on_change, **kw):
        super().__init__(master, bg=PANEL, highlightbackground=EDGE, highlightthickness=1, **kw)
        self.name = name
        self.accent = accent
        self.on_change = on_change
        self.roots: List[Path] = []
        top = tk.Frame(self, bg=PANEL); top.pack(fill="x", padx=7, pady=(6,3))
        tk.Label(top, text=f"SOURCE {name}", fg=accent, bg=PANEL, font=("TkFixedFont", 10, "bold")).pack(side="left")
        self.info = tk.Label(top, text="0 files", fg=MUTED, bg=PANEL, font=("TkFixedFont", 8)); self.info.pack(side="right")
        self.listbox = tk.Listbox(self, height=4, bg="#0a0d0e", fg=TEXT, selectbackground="#353b3f", borderwidth=0, highlightthickness=0, font=("TkFixedFont", 8))
        self.listbox.pack(fill="both", expand=True, padx=7, pady=3)
        buttons = tk.Frame(self, bg=PANEL); buttons.pack(fill="x", padx=6, pady=(2,6))
        self._button(buttons, "+DIR", self.add_dir).pack(side="left", padx=2)
        self._button(buttons, "+FILES", self.add_files).pack(side="left", padx=2)
        self._button(buttons, "CLEAR", self.clear).pack(side="right", padx=2)
    def _button(self, parent, text, cmd):
        return tk.Button(parent, text=text, command=cmd, bg=PANEL2, fg=TEXT, activebackground=EDGE, activeforeground=TEXT, relief="flat", bd=0, padx=6, pady=2, font=("TkFixedFont", 7, "bold"), cursor="hand2")
    def add_dir(self):
        p = filedialog.askdirectory(title=f"Palimpsest — choose SOURCE {self.name} folder")
        if p:
            self.roots.append(Path(p)); self.refresh(); self.on_change()
    def add_files(self):
        patterns = " ".join("*"+e for e in sorted(SUPPORTED))
        ps = filedialog.askopenfilenames(title=f"Palimpsest — choose SOURCE {self.name} files", filetypes=[("Texts / documents", patterns), ("All files", "*")])
        if ps:
            self.roots.extend(Path(p) for p in ps); self.refresh(); self.on_change()
    def clear(self):
        self.roots.clear(); self.refresh(); self.on_change()
    def refresh(self):
        self.listbox.delete(0, "end")
        for p in self.roots[-30:]:
            self.listbox.insert("end", str(p))
        n = len(iter_source_files(self.roots))
        self.info.config(text=f"{n} files")


class PalimpsestGUI(tk.Tk):
    def __init__(self, smoke_test=False):
        super().__init__()
        self.title(f"PALIMPSEST v{VERSION} — TABLETOP TEXT SYNTHESIZER")
        self.geometry("1180x760")
        self.minsize(980, 680)
        self.configure(bg=DARK)
        self.option_add("*Font", ("TkFixedFont", 9))
        self.protocol("WM_DELETE_WINDOW", self.destroy)

        self.workspace = HERE / "PALIMPSEST_WORK"
        self.cache_a = self.workspace / "CACHE_A"
        self.cache_b = self.workspace / "CACHE_B"
        self.output_dir = self.workspace / "OUTPUT"
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Engine parameters.
        self.mode = tk.StringVar(value="canto")
        self.unit = tk.StringVar(value="block")
        self.period_mode = tk.StringVar(value="free")
        self.language_mode = tk.StringVar(value="free")
        self.primary_language = tk.StringVar(value="fi")
        self.motif = tk.StringVar(value="")
        self.count = tk.IntVar(value=60)
        self.seed = tk.StringVar(value=str(random.SystemRandom().randrange(2**63)))
        self.ratio_a = tk.DoubleVar(value=0.50)
        self.continuity = tk.DoubleVar(value=0.62)
        self.motif_gravity = tk.DoubleVar(value=0.62)
        self.period_gravity = tk.DoubleVar(value=0.35)
        self.register_shift = tk.DoubleVar(value=0.34)
        self.preserve_run = tk.DoubleVar(value=0.34)
        self.rupture = tk.DoubleVar(value=0.12)
        self.return_rate = tk.DoubleVar(value=0.06)
        self.intrusion_rate = tk.DoubleVar(value=0.15)

        self.dirty = True
        self.last_output: Optional[Path] = None
        self.last_manifest: Optional[Path] = None
        self.last_chosen: List[dict] = []
        self.cur_index = 0
        self.decisions: Dict[str, str] = {}

        self._style_ttk()
        self._build()
        self._keys()
        self.set_status("READY — load two textual currents, or use only A for a single archive")
        if smoke_test:
            self.after(500, self.destroy)

    def _style_ttk(self):
        s = ttk.Style(self)
        try: s.theme_use("clam")
        except Exception: pass
        s.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=TEXT, arrowcolor=TEXT, bordercolor=EDGE, lightcolor=EDGE, darkcolor=EDGE)

    def _build(self):
        # header
        header = tk.Frame(self, bg=DARK); header.pack(fill="x", padx=10, pady=(8,4))
        tk.Label(header, text="PALIMPSEST", fg=TEXT, bg=DARK, font=("TkFixedFont", 18, "bold")).pack(side="left")
        tk.Label(header, text=f"v{VERSION}  /  TABLETOP TEXT SYNTHESIZER", fg=ACCENT, bg=DARK, font=("TkFixedFont", 8, "bold")).pack(side="left", padx=10, pady=(8,0))
        self.status = tk.Label(header, text="", fg=MUTED, bg=DARK, anchor="e", font=("TkFixedFont", 8)); self.status.pack(side="right", fill="x", expand=True)

        # two decks + central mode / utility area
        top = tk.Frame(self, bg=DARK); top.pack(fill="x", padx=10, pady=4)
        self.deck_a = SourceDeck(top, "A", ACCENT2, self.mark_dirty); self.deck_a.pack(side="left", fill="both", expand=True)

        center = tk.Frame(top, bg=PANEL, width=240, highlightbackground=EDGE, highlightthickness=1)
        center.pack(side="left", fill="y", padx=7); center.pack_propagate(False)
        tk.Label(center, text="ENGINE", fg=ACCENT, bg=PANEL, font=("TkFixedFont", 9, "bold")).pack(anchor="w", padx=8, pady=(7,3))
        modes = tk.Frame(center, bg=PANEL); modes.pack(fill="x", padx=6)
        for i, m in enumerate(("canto", "constellation", "ghost", "braid", "echo", "deck")):
            rb = tk.Radiobutton(modes, text=m.upper(), variable=self.mode, value=m, indicatoron=False, selectcolor="#3b3020", bg=PANEL2, fg=TEXT, activebackground=EDGE, activeforeground=TEXT, relief="flat", bd=0, padx=4, pady=3, font=("TkFixedFont", 7, "bold"))
            rb.grid(row=i//2, column=i%2, sticky="ew", padx=2, pady=2)
        modes.grid_columnconfigure((0,1), weight=1)

        form = tk.Frame(center, bg=PANEL); form.pack(fill="x", padx=8, pady=5)
        self._combo_row(form, "UNIT", self.unit, ("block","line","sentence","document"), 0)
        self._combo_row(form, "TIME", self.period_mode, ("free","same","cross","chronological"), 1)
        self._combo_row(form, "LANG", self.language_mode, ("free","same","primary-intrusions"), 2)
        row = tk.Frame(form, bg=PANEL); row.grid(row=3, column=0, columnspan=2, sticky="ew", pady=2)
        tk.Label(row, text="N", fg=MUTED, bg=PANEL, width=4, anchor="w", font=("TkFixedFont",7)).pack(side="left")
        tk.Entry(row, textvariable=self.count, width=7, bg="#0b0e0f", fg=TEXT, insertbackground=TEXT, relief="flat").pack(side="left")
        tk.Label(row, text=" FI/EN", fg=MUTED, bg=PANEL, font=("TkFixedFont",7)).pack(side="left", padx=(5,0))
        tk.Entry(row, textvariable=self.primary_language, width=4, bg="#0b0e0f", fg=TEXT, insertbackground=TEXT, relief="flat").pack(side="left")

        utilities = tk.Frame(center, bg=PANEL); utilities.pack(fill="x", side="bottom", padx=7, pady=7)
        self._flatbutton(utilities, "INGEST", self.ingest, ACCENT2).pack(side="left", fill="x", expand=True, padx=2)
        self._flatbutton(utilities, "GENERATE", self.generate, ACCENT).pack(side="left", fill="x", expand=True, padx=2)

        self.deck_b = SourceDeck(top, "B", BLUE, self.mark_dirty); self.deck_b.pack(side="left", fill="both", expand=True)

        # knob strip
        synth = tk.Frame(self, bg=PANEL, highlightbackground=EDGE, highlightthickness=1)
        synth.pack(fill="x", padx=10, pady=4)
        knobs = [
            ("A/B MIX", self.ratio_a), ("CONTINUITY", self.continuity), ("MOTIF", self.motif_gravity),
            ("TIME", self.period_gravity), ("REGISTER", self.register_shift), ("PRESERVE", self.preserve_run),
            ("RUPTURE", self.rupture), ("RETURN", self.return_rate), ("INTRUSION", self.intrusion_rate),
        ]
        for label, var in knobs:
            Knob(synth, label, var).pack(side="left", padx=2, pady=3)
        motifbox = tk.Frame(synth, bg=PANEL); motifbox.pack(side="left", fill="both", expand=True, padx=8, pady=7)
        tk.Label(motifbox, text="ATTRACTORS / MOTIFS", fg=MUTED, bg=PANEL, font=("TkFixedFont", 7, "bold")).pack(anchor="w")
        tk.Entry(motifbox, textvariable=self.motif, bg="#090c0d", fg=TEXT, insertbackground=TEXT, relief="flat", font=("TkFixedFont", 9)).pack(fill="x", pady=(3,7))
        seedrow = tk.Frame(motifbox, bg=PANEL); seedrow.pack(fill="x")
        tk.Label(seedrow, text="SEED", fg=MUTED, bg=PANEL, font=("TkFixedFont",7,"bold")).pack(side="left")
        tk.Entry(seedrow, textvariable=self.seed, bg="#090c0d", fg=TEXT, insertbackground=TEXT, relief="flat", width=18, font=("TkFixedFont",8)).pack(side="left", fill="x", expand=True, padx=5)
        self._flatbutton(seedrow, "NEW", self.new_seed, TEXT).pack(side="right")

        # main text / current fragment
        main = tk.Frame(self, bg=DARK); main.pack(fill="both", expand=True, padx=10, pady=(4,3))
        textframe = tk.Frame(main, bg=PANEL, highlightbackground=EDGE, highlightthickness=1)
        textframe.pack(side="left", fill="both", expand=True)
        texttop = tk.Frame(textframe, bg=PANEL); texttop.pack(fill="x", padx=8, pady=(6,3))
        tk.Label(texttop, text="COMPOSITE", fg=ACCENT, bg=PANEL, font=("TkFixedFont",8,"bold")).pack(side="left")
        self.outinfo = tk.Label(texttop, text="", fg=MUTED, bg=PANEL, font=("TkFixedFont",7)); self.outinfo.pack(side="right")
        body = tk.Frame(textframe, bg=PANEL); body.pack(fill="both", expand=True, padx=7, pady=(0,7))
        self.text = tk.Text(body, wrap="word", undo=False, bg="#07090a", fg=TEXT, insertbackground=TEXT, selectbackground="#3a4144", relief="flat", bd=0, padx=12, pady=10, font=("TkFixedFont", 10), spacing1=1, spacing3=4)
        scroll = tk.Scrollbar(body, command=self.text.yview, bg=PANEL2, troughcolor=DARK, relief="flat")
        self.text.config(yscrollcommand=scroll.set)
        self.text.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")

        curator = tk.Frame(main, bg=PANEL, width=230, highlightbackground=EDGE, highlightthickness=1)
        curator.pack(side="left", fill="y", padx=(7,0)); curator.pack_propagate(False)
        tk.Label(curator, text="FRAGMENT / HUMAN TOUCH", fg=ACCENT2, bg=PANEL, font=("TkFixedFont",8,"bold")).pack(anchor="w", padx=8, pady=(7,4))
        self.fragmeta = tk.Label(curator, text="No fragment", justify="left", anchor="nw", fg=MUTED, bg=PANEL, wraplength=210, font=("TkFixedFont",7))
        self.fragmeta.pack(fill="x", padx=8)
        self.fragtext = tk.Text(curator, height=11, wrap="word", bg="#0a0d0e", fg=TEXT, relief="flat", bd=0, padx=7, pady=7, font=("TkFixedFont",8))
        self.fragtext.pack(fill="both", expand=True, padx=7, pady=5)
        nav = tk.Frame(curator, bg=PANEL); nav.pack(fill="x", padx=6)
        self._flatbutton(nav, "◀", lambda:self.move_frag(-1), TEXT).pack(side="left", padx=2)
        self._flatbutton(nav, "KEEP", lambda:self.decide("keep"), ACCENT2).pack(side="left", padx=2)
        self._flatbutton(nav, "FREEZE", lambda:self.decide("freeze"), ACCENT).pack(side="left", padx=2)
        self._flatbutton(nav, "REJECT", lambda:self.decide("reject"), DANGER).pack(side="left", padx=2)
        self._flatbutton(nav, "▶", lambda:self.move_frag(1), TEXT).pack(side="right", padx=2)

        footer = tk.Frame(self, bg=DARK); footer.pack(fill="x", padx=10, pady=(2,8))
        tk.Label(footer, text="SPACE generate   Ctrl+S save as   Ctrl+I ingest   ←/→ fragments", fg=MUTED, bg=DARK, font=("TkFixedFont",7)).pack(side="left")
        self._flatbutton(footer, "COPY", self.copy_output, TEXT).pack(side="right", padx=2)
        self._flatbutton(footer, "SAVE AS", self.save_as, TEXT).pack(side="right", padx=2)
        self._flatbutton(footer, "OPEN OUTPUT", self.open_output_folder, TEXT).pack(side="right", padx=2)

    def _combo_row(self, parent, label, var, values, row):
        tk.Label(parent, text=label, fg=MUTED, bg=PANEL, width=5, anchor="w", font=("TkFixedFont",7)).grid(row=row, column=0, sticky="w", pady=2)
        box = ttk.Combobox(parent, textvariable=var, values=values, state="readonly", width=17, font=("TkFixedFont",7))
        box.grid(row=row, column=1, sticky="ew", pady=2); parent.grid_columnconfigure(1, weight=1)

    def _flatbutton(self, parent, text, cmd, fg=TEXT):
        return tk.Button(parent, text=text, command=cmd, bg=PANEL2, fg=fg, activebackground=EDGE, activeforeground=TEXT, relief="flat", bd=0, padx=7, pady=3, font=("TkFixedFont",7,"bold"), cursor="hand2")

    def _keys(self):
        self.bind("<space>", lambda e: self.generate())
        self.bind("<Control-s>", lambda e: self.save_as())
        self.bind("<Control-i>", lambda e: self.ingest())
        self.bind("<Left>", lambda e: self.move_frag(-1))
        self.bind("<Right>", lambda e: self.move_frag(1))

    def mark_dirty(self):
        self.dirty = True
        self.set_status("SOURCE CHANGED — ingest required")

    def set_status(self, text, color=MUTED):
        self.status.config(text=text, fg=color)
        self.update_idletasks()

    def new_seed(self):
        self.seed.set(str(random.SystemRandom().randrange(2**63)))
        self.set_status("NEW SEED")

    def ingest(self):
        if not self.deck_a.roots and not self.deck_b.roots:
            messagebox.showinfo("Palimpsest", "Load at least one source folder or file first.")
            return False
        self.set_status("INGESTING…", ACCENT)
        try:
            ra = ingest_side(self.deck_a.roots, self.cache_a)
            rb = ingest_side(self.deck_b.roots, self.cache_b)
            # The engine expects both folders to exist even if one side is empty.
            self.cache_a.mkdir(parents=True, exist_ok=True); self.cache_b.mkdir(parents=True, exist_ok=True)
            self.dirty = False
            self.deck_a.info.config(text=f"{ra.files_ok} ok / {ra.units_hint} blocks")
            self.deck_b.info.config(text=f"{rb.files_ok} ok / {rb.units_hint} blocks")
            failed = ra.files_failed + rb.files_failed
            msg = f"INGESTED A:{ra.files_ok}  B:{rb.files_ok}"
            if failed: msg += f"  / {failed} failed — see IMPORT_MAP.json"
            self.set_status(msg, ACCENT2 if not failed else ACCENT)
            return True
        except Exception as exc:
            self.set_status("INGEST FAILED", DANGER)
            messagebox.showerror("Palimpsest ingest", str(exc))
            return False

    def _args(self, out: Path):
        try: seed = int(self.seed.get().strip())
        except Exception:
            seed = random.SystemRandom().randrange(2**63); self.seed.set(str(seed))
        return SimpleNamespace(
            a=self.cache_a, b=self.cache_b, unit=self.unit.get(), mode=self.mode.get(),
            count=max(1, int(self.count.get())), ratio_a=float(self.ratio_a.get()),
            run_min=1, run_max=3, ghost_rate=max(0.02, float(self.intrusion_rate.get())),
            continuity=float(self.continuity.get()), motif=self.motif.get(),
            motif_gravity=float(self.motif_gravity.get()), period_mode=self.period_mode.get(),
            period_gravity=float(self.period_gravity.get()), language_mode=self.language_mode.get(),
            primary_language=self.primary_language.get().strip() or "fi", intrusion_rate=float(self.intrusion_rate.get()),
            register_shift=float(self.register_shift.get()), preserve_run=float(self.preserve_run.get()),
            local_radius=1, rupture=float(self.rupture.get()), candidate_sample=80, source_cooldown=3,
            return_rate=float(self.return_rate.get()), return_distance=7, constellation_growth=0.10,
            favorite_boost=1.8, curation=None, period_a="", period_b="", year_min=None, year_max=None,
            languages="", genres="", seed=seed, separator="blank", canto_break_every=0, out=out
        )

    def generate(self):
        if self.dirty and not self.ingest():
            return
        self.output_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        out = self.output_dir / f"palimpsest_{self.mode.get()}_{stamp}.txt"
        args = self._args(out)
        self.set_status("GENERATING…", ACCENT)
        try:
            rc = engine.cmd_compose(args)
            if rc != 0:
                raise RuntimeError("Composition engine returned an error")
            self.last_output = out
            self.last_manifest = out.with_suffix(out.suffix + ".manifest.json")
            text = out.read_text(encoding="utf-8")
            self.text.delete("1.0", "end"); self.text.insert("1.0", text)
            data = json.loads(self.last_manifest.read_text(encoding="utf-8"))
            self.last_chosen = data.get("output", [])
            self.cur_index = 0; self.show_fragment()
            self.outinfo.config(text=f"{self.mode.get().upper()} / {len(self.last_chosen)} units / seed {args.seed}")
            self.set_status(f"GENERATED — {out.name}", ACCENT2)
        except Exception as exc:
            self.set_status("GENERATION FAILED", DANGER)
            messagebox.showerror("Palimpsest", str(exc))

    def show_fragment(self):
        self.fragtext.delete("1.0", "end")
        if not self.last_chosen:
            self.fragmeta.config(text="No fragment")
            return
        self.cur_index %= len(self.last_chosen)
        e = self.last_chosen[self.cur_index]
        uid = e.get("uid", "")
        decision = self.decisions.get(uid, "—")
        self.fragmeta.config(text=f"{self.cur_index+1}/{len(self.last_chosen)}  {e.get('source_group')}:{e.get('source_file')}#{e.get('source_index')}\n{e.get('period')} / {e.get('genre')} / {e.get('language_hint')}\n{e.get('reason')}   [{decision}]")
        self.fragtext.insert("1.0", e.get("text", ""))

    def move_frag(self, delta):
        if self.last_chosen:
            self.cur_index = (self.cur_index + delta) % len(self.last_chosen); self.show_fragment()

    def decide(self, decision):
        if not self.last_chosen: return
        e = self.last_chosen[self.cur_index]; uid = e.get("uid")
        if uid:
            self.decisions[uid] = decision
            cpath = self.output_dir / "gui_curation.json"
            payload = {"program":"PALIMPSEST", "version":VERSION, "created_unix":time.time(), "decisions":self.decisions}
            cpath.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            self.show_fragment(); self.set_status(f"{decision.upper()} — fragment {self.cur_index+1}", ACCENT2 if decision != "reject" else DANGER)
            self.move_frag(1)

    def save_as(self):
        if not self.last_output or not self.last_output.exists():
            messagebox.showinfo("Palimpsest", "Generate a composition first.")
            return
        p = filedialog.asksaveasfilename(title="Save Palimpsest composition", defaultextension=".txt", filetypes=[("Text", "*.txt"), ("Markdown", "*.md"), ("All files", "*")], initialfile=self.last_output.name)
        if p:
            Path(p).write_text(self.text.get("1.0", "end-1c") + "\n", encoding="utf-8")
            self.set_status(f"SAVED — {p}", ACCENT2)

    def copy_output(self):
        text = self.text.get("1.0", "end-1c")
        if text:
            self.clipboard_clear(); self.clipboard_append(text); self.set_status("COPIED TO CLIPBOARD", ACCENT2)

    def open_output_folder(self):
        self.output_dir.mkdir(parents=True, exist_ok=True)
        try:
            if sys.platform.startswith("linux"):
                subprocess.Popen(["xdg-open", str(self.output_dir)])
            elif sys.platform == "darwin": subprocess.Popen(["open", str(self.output_dir)])
            elif os.name == "nt": os.startfile(str(self.output_dir))
        except Exception as exc:
            messagebox.showinfo("Output folder", str(self.output_dir))


def selftest() -> int:
    import tempfile
    with tempfile.TemporaryDirectory(prefix="palimpsest_v040_") as td:
        root = Path(td); a = root/"A"; b=root/"B"; a.mkdir(); b.mkdir()
        (a/"fi.txt").write_text("Yö painoi ikkunaa vasten.\n\nJoki muisti vanhan nimensä.", encoding="utf-8")
        (b/"en.html").write_text("<p>The machine remembered the river.</p><p>Another room opened.</p>", encoding="utf-8")
        ca=root/"CA"; cb=root/"CB"
        ra=ingest_side([a], ca); rb=ingest_side([b], cb)
        assert ra.files_ok==1 and rb.files_ok==1
        out=root/"out.txt"
        args=SimpleNamespace(a=ca,b=cb,unit="block",mode="canto",count=4,ratio_a=.5,run_min=1,run_max=2,ghost_rate=.2,continuity=.62,motif="yö,joki,river,machine",motif_gravity=.62,period_mode="free",period_gravity=.35,language_mode="free",primary_language="fi",intrusion_rate=.15,register_shift=.34,preserve_run=.34,local_radius=1,rupture=.12,candidate_sample=20,source_cooldown=3,return_rate=0.0,return_distance=4,constellation_growth=.1,favorite_boost=1.8,curation=None,period_a="",period_b="",year_min=None,year_max=None,languages="",genres="",seed=12345,separator="blank",canto_break_every=0,out=out)
        rc=engine.cmd_compose(args)
        assert rc==0 and out.exists() and out.read_text(encoding="utf-8").strip()
        print("PALIMPSEST v0.4.0 selftest OK")
        print(f"Formats: {', '.join(sorted(SUPPORTED))}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="PALIMPSEST v0.4.0 tabletop text synthesizer")
    ap.add_argument("--selftest", action="store_true", help="test importer + engine without opening GUI")
    ap.add_argument("--smoke-test", action="store_true", help="open GUI briefly and close (for packaging tests)")
    ns = ap.parse_args()
    if ns.selftest:
        return selftest()
    app = PalimpsestGUI(smoke_test=ns.smoke_test)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
