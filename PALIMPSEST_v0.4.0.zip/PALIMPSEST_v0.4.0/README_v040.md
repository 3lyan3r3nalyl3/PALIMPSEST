# PALIMPSEST v0.4.0 — Tabletop Text Synthesizer

Palimpsest v0.4.0 is the first GUI instrument edition of the literary montage engine.
It is designed as a compact two-deck tabletop machine rather than a word processor.

## Run

On Linux / Ubuntu / Debian:

```bash
cd PALIMPSEST_v0.4.0
./run_palimpsest.sh
```

or:

```bash
python3 palimpsest_v040.py
```

If Tkinter is missing on Debian/Ubuntu:

```bash
sudo apt install python3-tk
```

## Signal path

```text
SOURCE A  ──┐
            ├──>  CANTO / CONSTELLATION / GHOST / BRAID / ECHO / DECK  ──>  COMPOSITE
SOURCE B  ──┘
```

Each side can contain folders, individual files, or mixtures of both.
Sources are never modified. The GUI extracts documents into `PALIMPSEST_WORK/CACHE_A`
and `CACHE_B`, then the literary engine reads those temporary UTF-8 text copies.

## Ingest formats

- TXT / TEXT / ASC / LOG
- Markdown (`.md`, `.markdown`)
- RTF
- HTML
- DOCX
- ODT
- EPUB
- PDF

DOCX and ODT are read directly with Python's standard ZIP/XML tools. EPUB is read from
its HTML/XHTML contents. PDF uses `pypdf` when installed and otherwise tries the system
`pdftotext` command.

PDF should still be considered an *import format*, not Palimpsest's native archival
format. TXT / Markdown remain the cleanest literary source formats.

## The panel

### SOURCE A / SOURCE B
Two independent textual currents. `+DIR` adds a whole recursive folder; `+FILES` adds
individual documents. Use one side alone or feed two archives / periods / genres against
each other.

### Engines

- **CANTO** — principal prose-poem / montage engine.
- **CONSTELLATION** — attractor-driven gathering around motifs.
- **GHOST** — one textual current haunts another.
- **BRAID** — alternates runs from A and B.
- **ECHO** — follows lexical/morphological resonance.
- **DECK** — freer card-deck shuffle.

### Knobs

- **A/B MIX** — preference between source currents.
- **CONTINUITY** — strength of textual resonance.
- **MOTIF** — attraction toward entered motifs.
- **TIME** — importance of temporal-period behavior.
- **REGISTER** — willingness to shift poem/prose/fragment register.
- **PRESERVE** — chance that neighboring original fragments remain together in CANTO.
- **RUPTURE** — deliberate discontinuity.
- **RETURN** — leitmotivic reappearance of earlier fragments.
- **INTRUSION** — multilingual / ghost intrusion tendency.

Drag knobs vertically or use the mouse wheel.

### TIME

- `free` — dates do not govern transitions.
- `same` — same-period material attracts.
- `cross` — temporal strata deliberately meet.
- `chronological` — movement tends forward through known dates.

Undated material stays undated; Palimpsest does not invent dates.

### Human touch

The right-hand fragment monitor lets you inspect ancestry one fragment at a time and
mark a fragment:

- **KEEP**
- **FREEZE**
- **REJECT**

Decisions are stored in `PALIMPSEST_WORK/OUTPUT/gui_curation.json`. This v0.4 GUI records
them; later versions can feed the same decisions more deeply into breeding / mutation.

## Output

Every generated composition produces:

- `.txt` composite
- `.manifest.json` with full fragment ancestry
- `.lineage.tsv`

under `PALIMPSEST_WORK/OUTPUT/`.

The large preview can be copied or exported with **SAVE AS**.

## Keyboard

- `Space` — generate
- `Ctrl+I` — ingest
- `Ctrl+S` — Save As
- `Left / Right` — previous / next fragment

## Self-test

```bash
python3 palimpsest_v040.py --selftest
```

A packaging smoke test is also available:

```bash
xvfb-run -a python3 palimpsest_v040.py --smoke-test
```

## Design boundary

Palimpsest still does **not** automatically rewrite the archive. It extracts text,
recombines units, preserves provenance, and lets human recognition decide what matters.
The GUI is intentionally closer to a small instrument than to Scrivener, Word, or a DAW.
